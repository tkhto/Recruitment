export default {
    Host:"http://api.offend.com:8000",
}