import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/components/index.vue'
import Home from '@/components/Home'
import Profile from '@/components/Profile'
import Comdetail from '@/components/Comdetail'
import Posdetail from '@/components/Posdetail'
import Positions from '@/components/Positions'
import Companys from '@/components/Companys'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      redirect: '/home',
    },
    {
      path: '/home',
      component: Index,
      children: [
        {
          path: '',
          component: Home
        },
        {
          path: '/profile/:id',
          component: Profile
        },
        {
          path: '/company/:id',
          component: Comdetail
        },
        {
          path: '/position/:id',
          component: Posdetail
        },
        {
          path: '/positions',
          component: Positions
        },
        {
          path: '/companys',
          component: Companys
        }
      ]
    }
  ]
})
