<template>
  <div class="collections">
      收藏
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>