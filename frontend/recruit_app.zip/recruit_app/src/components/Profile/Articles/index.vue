<template>
  <div class="article">
      文章
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>